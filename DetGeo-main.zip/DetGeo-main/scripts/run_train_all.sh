sh scripts/run_train_droneaerial.sh
wait
sh scripts/run_train_svi.sh
