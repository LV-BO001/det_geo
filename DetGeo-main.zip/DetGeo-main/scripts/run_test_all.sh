sh scripts/run_test_droneaerial.sh
wait
sh scripts/run_test_svi.sh
